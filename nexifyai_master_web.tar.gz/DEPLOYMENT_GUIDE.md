# 🚀 NeXifyAI MASTER - Deployment Guide

**Version:** 1.0.0  
**Erstellt:** 2025-11-05  
**Für:** Pascal Courbois

---

## ✅ PRE-DEPLOYMENT CHECKLIST

### 1. Supabase Setup

#### A. Migration ausführen
```bash
# Im MyDispatch Repository (wo die Migration liegt):
cd /workspace

# Migration deployen
npx supabase db push --db-url "postgresql://postgres:[YOUR_PASSWORD]@db.[YOUR_PROJECT_ID].supabase.co:5432/postgres"

# Oder via Supabase Dashboard:
# 1. Gehe zu: https://supabase.com/dashboard/project/ygpwuiygivxoqtyoigtg/sql/new
# 2. Kopiere kompletten Inhalt aus: supabase/migrations/20251105000001_create_nexify_master_agent_schema.sql
# 3. Klicke "Run"
```

#### B. User erstellen
```bash
# Via Supabase Dashboard:
# 1. Gehe zu: https://supabase.com/dashboard/project/ygpwuiygivxoqtyoigtg/auth/users
# 2. Klicke "Add User"
# 3. Email: courbois1981@gmail.com
# 4. Password: 1def!xO2022!!
# 5. Confirm
```

#### C. Edge Functions deployen
```bash
# Im MyDispatch Repository:
npx supabase functions deploy nexify-agent-chat
npx supabase functions deploy nexify-agent-execute
```

---

## 📦 GITHUB REPOSITORY SETUP

### 1. Neues Repository erstellen

```bash
# Via GitHub Web:
# 1. Gehe zu: https://github.com/new
# 2. Repository Name: nexifyai-master-app
# 3. Description: NeXifyAI MASTER - Autonomous Agent Application
# 4. Public/Private: Nach Wahl
# 5. Create Repository

# Oder via GitHub CLI:
gh repo create nexifyai-master-app --public --description "NeXifyAI MASTER - Autonomous Agent Application"
```

### 2. Code hochladen

```bash
# Im /tmp/nexifyai-master-app Verzeichnis:
cd /tmp/nexifyai-master-app

# Git konfigurieren
git add .
git commit -m "Initial commit: NeXifyAI MASTER App V1.0"

# Remote hinzufügen (ersetze YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/nexifyai-master-app.git

# Push
git push -u origin main
```

---

## ▲ VERCEL DEPLOYMENT

### 1. Vercel Account vorbereiten

```bash
# Vercel CLI installieren
npm i -g vercel

# Login
vercel login
```

### 2. Neues Projekt erstellen

```bash
# Im Repository-Verzeichnis:
cd /tmp/nexifyai-master-app

# Vercel Projekt erstellen
vercel

# Fragen beantworten:
# ? Set up and deploy "~/tmp/nexifyai-master-app"? [Y/n] Y
# ? Which scope do you want to deploy to? Your Scope
# ? Link to existing project? [y/N] N
# ? What's your project's name? nexifyai-master-app
# ? In which directory is your code located? ./
# ? Want to override the settings? [y/N] N
```

### 3. Environment Variables setzen

```bash
# Via Vercel CLI:
vercel env add VITE_SUPABASE_URL
# Wert eingeben: https://ygpwuiygivxoqtyoigtg.supabase.co

vercel env add VITE_SUPABASE_ANON_KEY
# Wert eingeben: [Dein Supabase Anon Key]

# Oder via Vercel Dashboard:
# 1. Gehe zu: https://vercel.com/dashboard
# 2. Wähle Projekt: nexifyai-master-app
# 3. Settings → Environment Variables
# 4. Füge hinzu:
#    - VITE_SUPABASE_URL
#    - VITE_SUPABASE_ANON_KEY
```

### 4. Production Deployment

```bash
# Deploy to production
vercel --prod

# Output wird sein:
# ✅ Deployed to production: https://nexifyai-master-app.vercel.app
```

---

## 🔐 GITHUB SECRETS (für CI/CD)

Gehe zu: `https://github.com/YOUR_USERNAME/nexifyai-master-app/settings/secrets/actions`

Füge folgende Secrets hinzu:

1. **VITE_SUPABASE_URL**
   - Value: `https://ygpwuiygivxoqtyoigtg.supabase.co`

2. **VITE_SUPABASE_ANON_KEY**
   - Value: [Dein Supabase Anon Key]

3. **VERCEL_TOKEN**
   - Erstellen: https://vercel.com/account/tokens
   - Value: [Generated Token]

4. **VERCEL_ORG_ID**
   - Finde in: Vercel Dashboard → Settings → General
   - Value: [Your Org ID]

5. **VERCEL_PROJECT_ID**
   - Finde in: Project Settings → General
   - Value: [Your Project ID]

---

## ✅ POST-DEPLOYMENT CHECKLIST

### 1. Funktionalität testen

```bash
# 1. Öffne App: https://nexifyai-master-app.vercel.app
# 2. Login testen:
#    - Email: courbois1981@gmail.com
#    - Passwort: 1def!xO2022!!
# 3. Dashboard sollte laden
# 4. Chat testen: Nachricht senden
# 5. Agent Status prüfen
```

### 2. Supabase Tables prüfen

```sql
-- Via Supabase SQL Editor:
-- https://supabase.com/dashboard/project/ygpwuiygivxoqtyoigtg/sql/new

-- Prüfe ob Schema existiert:
SELECT schema_name 
FROM information_schema.schemata 
WHERE schema_name = 'nexify_master_agent';

-- Prüfe Tables:
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'nexify_master_agent';

-- Prüfe Capabilities:
SELECT * FROM nexify_master_agent.agent_capabilities;
```

### 3. Edge Functions testen

```bash
# Test nexify-agent-chat:
curl -X POST https://ygpwuiygivxoqtyoigtg.supabase.co/functions/v1/nexify-agent-chat \
  -H "Authorization: Bearer YOUR_USER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello"}'

# Expected: {"success":true,"response":"...","session_id":"..."}
```

---

## 🎯 SUCCESS CRITERIA

✅ **Deployment erfolgreich wenn:**

1. App erreichbar unter: https://nexifyai-master-app.vercel.app
2. Login funktioniert mit festem User
3. Dashboard lädt und zeigt Agent Status
4. Chat funktioniert (Nachrichten werden gespeichert)
5. Supabase Tables sind vorhanden und haben Daten
6. Edge Functions antworten korrekt

---

## 🐛 TROUBLESHOOTING

### Problem: "Missing Supabase environment variables"

**Lösung:**
```bash
# Prüfe Environment Variables:
vercel env ls

# Füge hinzu falls fehlen:
vercel env add VITE_SUPABASE_URL
vercel env add VITE_SUPABASE_ANON_KEY

# Re-deploy:
vercel --prod
```

### Problem: "Unauthorized" beim Login

**Lösung:**
1. Prüfe ob User in Supabase existiert
2. Gehe zu: Supabase Dashboard → Authentication → Users
3. Suche nach: courbois1981@gmail.com
4. Falls nicht vorhanden → User erstellen

### Problem: "Table does not exist"

**Lösung:**
```bash
# Migration erneut ausführen:
npx supabase db push --db-url "postgresql://postgres:[PASSWORD]@db.ygpwuiygivxoqtyoigtg.supabase.co:5432/postgres"
```

### Problem: Edge Functions nicht erreichbar

**Lösung:**
```bash
# Edge Functions neu deployen:
npx supabase functions deploy nexify-agent-chat
npx supabase functions deploy nexify-agent-execute

# Logs prüfen:
npx supabase functions logs nexify-agent-chat
```

---

## 📞 SUPPORT

Bei Problemen kontaktiere:
- **Email:** courbois1981@gmail.com
- **Telefon:** +31 6 133 188 56

---

**Viel Erfolg mit deinem NeXifyAI MASTER! 🚀**
