import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    'Missing Supabase environment variables. Please check your .env.local file.'
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
});

// Database Types (auto-generated from Supabase)
export interface AgentSession {
  id: string;
  user_id: string;
  session_start: string;
  session_end: string | null;
  session_duration_seconds: number | null;
  loaded_projects: string[];
  loaded_knowledge: Record<string, unknown>;
  active_tasks: number;
  status: 'active' | 'paused' | 'completed' | 'error';
  created_at: string;
  updated_at: string;
}

export interface AgentAction {
  id: string;
  session_id: string;
  action_type: string;
  action_description: string;
  action_input: Record<string, unknown> | null;
  action_output: Record<string, unknown> | null;
  status: 'pending' | 'in_progress' | 'completed' | 'failed' | 'cancelled';
  error_message: string | null;
  started_at: string | null;
  completed_at: string | null;
  duration_ms: number | null;
  affected_files: string[];
  affected_projects: string[];
  created_at: string;
  updated_at: string;
}

export interface AgentCapability {
  id: string;
  capability_name: string;
  capability_type: 'api' | 'tool' | 'integration' | 'skill';
  capability_description: string | null;
  is_enabled: boolean;
  requires_credentials: boolean;
  credentials_configured: boolean;
  usage_count: number;
  success_count: number;
  error_count: number;
  last_used_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface AgentChatMessage {
  id: string;
  session_id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  tokens_used: number | null;
  model_used: string | null;
  response_time_ms: number | null;
  related_action_ids: string[];
  created_at: string;
}
