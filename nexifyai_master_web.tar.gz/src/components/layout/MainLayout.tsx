import { Outlet } from 'react-router-dom';
import { useEffect } from 'react';
import Header from './Header';
import Sidebar from './Sidebar';
import { useAgentStore } from '@/store/agentStore';

export default function MainLayout() {
  const { initSession } = useAgentStore();

  useEffect(() => {
    // Initialize agent session on mount
    initSession();
  }, [initSession]);

  return (
    <div className="h-screen flex flex-col bg-slate-50">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar />

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
