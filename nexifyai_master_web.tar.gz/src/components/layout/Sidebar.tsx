import { NavLink } from 'react-router-dom';
import {
  Home,
  MessageSquare,
  FolderKanban,
  Brain,
  BarChart3,
  Settings,
} from 'lucide-react';

const navItems = [
  { path: '/', label: 'Dashboard', icon: Home },
  { path: '/chat', label: 'Chat', icon: MessageSquare },
  { path: '/projects', label: 'Projects', icon: FolderKanban },
  { path: '/knowledge', label: 'Knowledge', icon: Brain },
  { path: '/analytics', label: 'Analytics', icon: BarChart3 },
  { path: '/settings', label: 'Settings', icon: Settings },
];

export default function Sidebar() {
  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col">
      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  isActive
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-700 hover:bg-slate-100'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <Icon className={`w-5 h-5 ${isActive ? 'text-white' : ''}`} />
                  <span className="font-medium">{item.label}</span>
                </>
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* Agent Status */}
      <div className="p-4 border-t border-slate-200">
        <div className="bg-slate-50 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-slate-900 mb-2">
            Agent Status
          </h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600">Status</span>
              <span className="font-medium text-emerald-600">Active</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Actions</span>
              <span className="font-medium text-slate-900">127</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Uptime</span>
              <span className="font-medium text-slate-900">2h 34m</span>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
