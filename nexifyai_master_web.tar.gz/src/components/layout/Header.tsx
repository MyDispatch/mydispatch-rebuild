import { Settings, LogOut, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';
import { useAgentStore } from '@/store/agentStore';

export default function Header() {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const { isAgentOnline } = useAgentStore();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6">
      {/* Logo & Title */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-slate-700 rounded-lg flex items-center justify-center">
          <span className="text-white font-bold text-lg">N</span>
        </div>
        <div>
          <h1 className="text-lg font-bold text-slate-900">NeXifyAI MASTER</h1>
          <p className="text-xs text-slate-600">Autonomous Agent</p>
        </div>
      </div>

      {/* Right Actions */}
      <div className="flex items-center gap-4">
        {/* Agent Status */}
        <div className="flex items-center gap-2">
          <div
            className={`w-2 h-2 rounded-full ${
              isAgentOnline ? 'bg-emerald-500' : 'bg-slate-300'
            }`}
          />
          <span className="text-sm text-slate-700">
            {isAgentOnline ? 'Online' : 'Offline'}
          </span>
        </div>

        {/* Settings */}
        <button
          onClick={() => navigate('/settings')}
          className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          aria-label="Settings"
        >
          <Settings className="w-5 h-5 text-slate-700" />
        </button>

        {/* User Menu */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-slate-700" />
            <span className="text-sm text-slate-700">{user?.email}</span>
          </div>
          <button
            onClick={handleLogout}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            aria-label="Logout"
          >
            <LogOut className="w-5 h-5 text-slate-700" />
          </button>
        </div>
      </div>
    </header>
  );
}
