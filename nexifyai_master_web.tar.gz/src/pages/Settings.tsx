import { useState, useEffect } from 'react';
import { supabase, AgentCapability } from '@/lib/supabase';
import { Check, X } from 'lucide-react';

export default function Settings() {
  const [capabilities, setCapabilities] = useState<AgentCapability[]>([]);

  useEffect(() => {
    loadCapabilities();
  }, []);

  const loadCapabilities = async () => {
    const { data } = await supabase
      .from('nexify_master_agent.agent_capabilities')
      .select('*')
      .order('capability_type', { ascending: true });

    if (data) setCapabilities(data);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Settings</h1>
        <p className="text-slate-600">Konfiguriere deinen Agent</p>
      </div>

      {/* Capabilities */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
        <h2 className="text-xl font-bold text-slate-900 mb-4">Capabilities</h2>

        <div className="space-y-4">
          {capabilities.map((cap) => (
            <div
              key={cap.id}
              className="flex items-center justify-between p-4 border border-slate-200 rounded-lg"
            >
              <div className="flex-1">
                <h3 className="font-semibold text-slate-900">
                  {cap.capability_name}
                </h3>
                <p className="text-sm text-slate-600">
                  {cap.capability_description}
                </p>
                <div className="flex gap-2 mt-2">
                  <span className="text-xs bg-slate-100 px-2 py-1 rounded">
                    {cap.capability_type}
                  </span>
                  {cap.requires_credentials && (
                    <span className="text-xs bg-amber-100 text-amber-700 px-2 py-1 rounded">
                      Requires Credentials
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right text-sm">
                  <p className="text-slate-600">
                    {cap.usage_count} uses
                  </p>
                  <p className="text-slate-500 text-xs">
                    {cap.success_count} success
                  </p>
                </div>

                <div
                  className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    cap.is_enabled
                      ? 'bg-emerald-100 text-emerald-600'
                      : 'bg-slate-100 text-slate-400'
                  }`}
                >
                  {cap.is_enabled ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    <X className="w-5 h-5" />
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
