import { useEffect, useState } from 'react';
import { useAgentStore } from '@/store/agentStore';
import { supabase } from '@/lib/supabase';
import {
  Activity,
  Zap,
  CheckCircle2,
  Clock,
  TrendingUp,
  AlertCircle,
} from 'lucide-react';

export default function Dashboard() {
  const { capabilities, isAgentOnline } = useAgentStore();
  const [stats, setStats] = useState({
    totalActions: 0,
    completedActions: 0,
    failedActions: 0,
    avgDuration: 0,
  });

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      // Get total actions
      const { count: total } = await supabase
        .from('nexify_master_agent.agent_actions')
        .select('*', { count: 'exact', head: true });

      // Get completed actions
      const { count: completed } = await supabase
        .from('nexify_master_agent.agent_actions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'completed');

      // Get failed actions
      const { count: failed } = await supabase
        .from('nexify_master_agent.agent_actions')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'failed');

      setStats({
        totalActions: total || 0,
        completedActions: completed || 0,
        failedActions: failed || 0,
        avgDuration: 0, // TODO: Calculate average
      });
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  };

  const statCards = [
    {
      label: 'Total Actions',
      value: stats.totalActions,
      icon: Activity,
      color: 'text-slate-700',
      bgColor: 'bg-slate-100',
    },
    {
      label: 'Completed',
      value: stats.completedActions,
      icon: CheckCircle2,
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-100',
    },
    {
      label: 'Failed',
      value: stats.failedActions,
      icon: AlertCircle,
      color: 'text-red-600',
      bgColor: 'bg-red-100',
    },
    {
      label: 'Success Rate',
      value: stats.totalActions
        ? `${Math.round((stats.completedActions / stats.totalActions) * 100)}%`
        : '0%',
      icon: TrendingUp,
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-100',
    },
  ];

  const enabledCapabilities = capabilities.filter((c) => c.is_enabled);
  const configuredCapabilities = capabilities.filter(
    (c) => c.credentials_configured
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Dashboard</h1>
        <p className="text-slate-600">
          Übersicht über deinen NeXifyAI MASTER Agent
        </p>
      </div>

      {/* Agent Status Banner */}
      <div
        className={`rounded-xl p-6 ${
          isAgentOnline
            ? 'bg-emerald-50 border border-emerald-200'
            : 'bg-slate-100 border border-slate-200'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div
              className={`w-12 h-12 rounded-xl ${
                isAgentOnline ? 'bg-emerald-500' : 'bg-slate-300'
              } flex items-center justify-center`}
            >
              <Zap
                className={`w-6 h-6 ${
                  isAgentOnline ? 'text-white' : 'text-slate-500'
                }`}
              />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">
                Agent Status: {isAgentOnline ? 'Online' : 'Offline'}
              </h2>
              <p className="text-sm text-slate-600">
                {isAgentOnline
                  ? 'Bereit für Aufgaben'
                  : 'Agent ist offline'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <div
              key={stat.label}
              className="bg-white rounded-xl p-6 shadow-sm border border-slate-200"
            >
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
              <p className="text-sm text-slate-600 mb-1">{stat.label}</p>
              <p className="text-3xl font-bold text-slate-900">{stat.value}</p>
            </div>
          );
        })}
      </div>

      {/* Capabilities */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200">
        <h3 className="text-xl font-bold text-slate-900 mb-4">Capabilities</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-slate-50 rounded-lg p-4">
            <p className="text-sm text-slate-600 mb-2">Enabled</p>
            <p className="text-2xl font-bold text-slate-900">
              {enabledCapabilities.length} / {capabilities.length}
            </p>
          </div>
          <div className="bg-slate-50 rounded-lg p-4">
            <p className="text-sm text-slate-600 mb-2">Configured</p>
            <p className="text-2xl font-bold text-slate-900">
              {configuredCapabilities.length} / {capabilities.length}
            </p>
          </div>
        </div>

        {/* Capability List */}
        <div className="mt-4 space-y-2">
          {capabilities.slice(0, 5).map((cap) => (
            <div
              key={cap.id}
              className="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-slate-50"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-2 h-2 rounded-full ${
                    cap.is_enabled ? 'bg-emerald-500' : 'bg-slate-300'
                  }`}
                />
                <span className="text-sm font-medium text-slate-900">
                  {cap.capability_name}
                </span>
                <span className="text-xs text-slate-500 bg-slate-100 px-2 py-1 rounded">
                  {cap.capability_type}
                </span>
              </div>
              <span className="text-sm text-slate-600">
                {cap.usage_count} uses
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
