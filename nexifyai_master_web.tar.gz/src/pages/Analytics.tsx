export default function Analytics() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Analytics</h1>
        <p className="text-slate-600">Analysiere Agent-Performance</p>
      </div>

      <div className="bg-white rounded-xl p-12 shadow-sm border border-slate-200 text-center">
        <p className="text-slate-500">Coming soon...</p>
      </div>
    </div>
  );
}
