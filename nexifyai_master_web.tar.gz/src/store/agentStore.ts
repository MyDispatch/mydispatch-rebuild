import { create } from 'zustand';
import { supabase, AgentSession, AgentCapability } from '@/lib/supabase';

interface AgentState {
  currentSession: AgentSession | null;
  capabilities: AgentCapability[];
  isAgentOnline: boolean;
  actionCount: number;
  
  // Actions
  initSession: () => Promise<void>;
  endSession: () => Promise<void>;
  loadCapabilities: () => Promise<void>;
  setAgentStatus: (online: boolean) => void;
}

export const useAgentStore = create<AgentState>((set, get) => ({
  currentSession: null,
  capabilities: [],
  isAgentOnline: false,
  actionCount: 0,

  initSession: async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Create new session
      const { data: session, error } = await supabase
        .from('nexify_master_agent.agent_sessions')
        .insert({
          user_id: user.id,
          status: 'active',
        })
        .select()
        .single();

      if (error) throw error;

      set({ currentSession: session, isAgentOnline: true });

      // Load capabilities
      await get().loadCapabilities();
    } catch (error) {
      console.error('Failed to init session:', error);
    }
  },

  endSession: async () => {
    const { currentSession } = get();
    if (!currentSession) return;

    try {
      const duration = Math.floor(
        (Date.now() - new Date(currentSession.session_start).getTime()) / 1000
      );

      await supabase
        .from('nexify_master_agent.agent_sessions')
        .update({
          session_end: new Date().toISOString(),
          session_duration_seconds: duration,
          status: 'completed',
        })
        .eq('id', currentSession.id);

      set({ currentSession: null, isAgentOnline: false });
    } catch (error) {
      console.error('Failed to end session:', error);
    }
  },

  loadCapabilities: async () => {
    try {
      const { data, error } = await supabase
        .from('nexify_master_agent.agent_capabilities')
        .select('*')
        .order('capability_type', { ascending: true });

      if (error) throw error;

      set({ capabilities: data || [] });
    } catch (error) {
      console.error('Failed to load capabilities:', error);
    }
  },

  setAgentStatus: (online: boolean) => {
    set({ isAgentOnline: online });
  },
}));
