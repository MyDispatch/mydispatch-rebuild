#!/bin/bash

# 🚀 Push Script für NeXifyAI MASTER Web
# Repository: https://github.com/u4231458123-droid/nexifyai_master_web_00

echo "🚀 NeXifyAI MASTER Web - Push to GitHub"
echo "======================================="
echo ""

# Navigiere zum Repository
cd /workspace/nexifyai_master_web

# Entferne alte Remote (falls vorhanden)
git remote remove origin 2>/dev/null || true

# Füge neue Remote hinzu
echo "📡 Adding remote..."
git remote add origin https://github.com/u4231458123-droid/nexifyai_master_web_00.git

# Stelle sicher, dass Branch 'main' heißt
echo "🔀 Ensuring branch is 'main'..."
git branch -M main

# Push
echo "📤 Pushing to GitHub..."
echo ""
echo "⚠️  Du wirst nach deinen GitHub Credentials gefragt:"
echo "   Username: u4231458123-droid"
echo "   Password: [Dein GitHub Personal Access Token]"
echo ""
echo "   Token erstellen unter:"
echo "   https://github.com/settings/tokens/new"
echo "   (Scope: repo)"
echo ""

git push -u origin main

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ SUCCESS! Code ist auf GitHub!"
    echo ""
    echo "🌐 Repository: https://github.com/u4231458123-droid/nexifyai_master_web_00"
    echo ""
    echo "📋 Nächste Schritte:"
    echo "   1. Öffne: https://github.com/u4231458123-droid/nexifyai_master_web_00"
    echo "   2. Prüfe ob alle Dateien da sind"
    echo "   3. Weiter mit Vercel Deployment (siehe FINAL_INSTRUCTIONS.md)"
else
    echo ""
    echo "❌ Push fehlgeschlagen!"
    echo ""
    echo "🔧 Mögliche Lösungen:"
    echo "   1. Erstelle Personal Access Token: https://github.com/settings/tokens/new"
    echo "   2. Oder nutze SSH: git remote set-url origin git@github.com:u4231458123-droid/nexifyai_master_web_00.git"
    echo "   3. Siehe GITHUB_SETUP.md für Details"
fi
