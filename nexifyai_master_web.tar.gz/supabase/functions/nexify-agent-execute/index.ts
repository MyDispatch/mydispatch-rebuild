import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Missing Supabase environment variables');
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    const { action_type, action_description, action_input, session_id } =
      await req.json();

    console.log('[nexify-agent-execute] Request:', {
      action_type,
      action_description,
      session_id,
    });

    // Validate input
    if (!action_type || !action_description) {
      throw new Error('Missing required fields');
    }

    // Get user from JWT
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    // Create action record
    const { data: action, error: actionError } = await supabase
      .from('nexify_master_agent.agent_actions')
      .insert({
        session_id: session_id,
        action_type,
        action_description,
        action_input,
        status: 'in_progress',
        started_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (actionError) throw actionError;

    const startTime = Date.now();

    // Execute action based on type
    let result;
    let status = 'completed';
    let errorMessage = null;

    try {
      result = await executeAction(action_type, action_input);
    } catch (error) {
      status = 'failed';
      errorMessage = error.message;
      result = { error: error.message };
    }

    const duration = Date.now() - startTime;

    // Update action record
    const { error: updateError } = await supabase
      .from('nexify_master_agent.agent_actions')
      .update({
        status,
        action_output: result,
        error_message: errorMessage,
        completed_at: new Date().toISOString(),
        duration_ms: duration,
      })
      .eq('id', action.id);

    if (updateError) throw updateError;

    console.log('[nexify-agent-execute] Success:', {
      action_id: action.id,
      duration,
      status,
    });

    return new Response(
      JSON.stringify({
        success: status === 'completed',
        action_id: action.id,
        action_output: result,
        duration_ms: duration,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('[nexify-agent-execute] Error:', error);

    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

/**
 * Execute action based on type
 */
async function executeAction(
  actionType: string,
  input: any
): Promise<any> {
  console.log('[executeAction]', actionType, input);

  switch (actionType) {
    case 'code_generation':
      return await executeCodeGeneration(input);

    case 'file_read':
      return await executeFileRead(input);

    case 'knowledge_query':
      return await executeKnowledgeQuery(input);

    default:
      throw new Error(`Unsupported action type: ${actionType}`);
  }
}

async function executeCodeGeneration(input: any): Promise<any> {
  // Placeholder
  return {
    code: '// Generated code placeholder',
    language: input.language || 'typescript',
  };
}

async function executeFileRead(input: any): Promise<any> {
  // Placeholder
  return {
    content: '// File content placeholder',
    path: input.path,
  };
}

async function executeKnowledgeQuery(input: any): Promise<any> {
  // Placeholder
  return {
    results: [],
    query: input.query,
  };
}
