import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.75.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    console.log('[nexify-agent-chat] Environment check:', {
      hasSupabaseUrl: !!supabaseUrl,
      hasSupabaseKey: !!supabaseKey,
    });

    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Missing Supabase environment variables');
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    const { message, session_id, context } = await req.json();

    console.log('[nexify-agent-chat] Request:', {
      message,
      session_id,
      hasContext: !!context,
    });

    // Validate input
    if (!message || typeof message !== 'string') {
      throw new Error('Invalid message');
    }

    // Get user from JWT
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    console.log('[nexify-agent-chat] User:', user.id);

    // Get or create session
    let sessionId = session_id;

    if (!sessionId) {
      const { data: newSession, error: sessionError } = await supabase
        .from('nexify_master_agent.agent_sessions')
        .insert({
          user_id: user.id,
          status: 'active',
        })
        .select()
        .single();

      if (sessionError) throw sessionError;

      sessionId = newSession.id;
      console.log('[nexify-agent-chat] Created new session:', sessionId);
    }

    // Save user message
    const { error: userMsgError } = await supabase
      .from('nexify_master_agent.agent_chat_messages')
      .insert({
        session_id: sessionId,
        role: 'user',
        content: message,
      });

    if (userMsgError) throw userMsgError;

    // Generate AI response (Placeholder - Replace with actual AI integration)
    const response = await generateAgentResponse(message, context);

    // Save assistant message
    const { error: assistantMsgError } = await supabase
      .from('nexify_master_agent.agent_chat_messages')
      .insert({
        session_id: sessionId,
        role: 'assistant',
        content: response,
        model_used: 'placeholder',
      });

    if (assistantMsgError) throw assistantMsgError;

    console.log('[nexify-agent-chat] Success');

    return new Response(
      JSON.stringify({
        success: true,
        response,
        session_id: sessionId,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('[nexify-agent-chat] Error:', error);

    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

/**
 * Generate agent response
 * TODO: Integrate with OpenAI/Anthropic/other AI provider
 */
async function generateAgentResponse(
  message: string,
  context?: any
): Promise<string> {
  // Placeholder logic - Replace with actual AI integration
  const lowerMessage = message.toLowerCase();

  if (lowerMessage.includes('hello') || lowerMessage.includes('hallo')) {
    return 'Hallo! Ich bin dein NeXifyAI MASTER. Wie kann ich dir helfen?';
  }

  if (lowerMessage.includes('help') || lowerMessage.includes('hilfe')) {
    return 'Ich kann dir bei folgenden Aufgaben helfen:\n\n- Code generieren und analysieren\n- Projekte verwalten\n- Deployments durchführen\n- Knowledge Base durchsuchen\n\nWas möchtest du tun?';
  }

  if (lowerMessage.includes('status')) {
    return 'Mein Status: ✅ Online und bereit!\n\n- Alle Systeme funktional\n- Capabilities geladen\n- Bereit für Aufgaben';
  }

  // Default response
  return `Ich habe deine Nachricht verstanden: "${message}"\n\nMomentan bin ich ein Platzhalter. Bald werde ich mit echten AI-Modellen integriert und kann dir bei komplexen Aufgaben helfen!`;
}
